#pragma once
#include<string>
#include<istream>
#include<exception>
using namespace std;
using cstring = char*;

enum TokenType{
	STRING,
	INT,
	DOUBLE,
	OBJECT,
};

struct Token{


	~Token()
	{
		if (type == OBJECT)
		{
			delete objectKeys;
			delete objectValues;
		}
	}
	TokenType type;
	union{
		cstring str;
		int integer;
		double real;
		struct{
			Token* objectKeys;
			Token* objectValues;
			int objectSize;
		};
	};
	Token& operator[](int i);
	Token& operator[](double real);
	Token& operator[](cstring str);
};
using JSON = Token;

class Parser
{
private:
	int GetObjectSize(istream& in);
	int GetArraySize(istream& in);
public:
	Parser();
	~Parser();

	JSON Parse(istream& in);


};

