#include "Parser.h"

static void IgnoreSpace(istream& in);
static char GetChar(istream& in);

static void IgnoreSpace(istream& in)
{
	while (isspace(in.peek()))
		in.get();
}
static char GetChar(istream& in)
{
	IgnoreSpace(in);
	char ret = in.get();
	IgnoreSpace(in);
	return ret;
}

Token& Token::operator[](int integer)
{
	int index;
	for (int i = 0; i < objectSize; i++)
	{
		if (objectKeys[i].integer == integer)
		{
			index = objectKeys[i].integer;
			break;
		}
	}
	return objectValues[index];
}
Token& Token::operator[](double real)
{
	int index;
	for (int i = 0; i < objectSize; i++)
	{
		if (objectKeys[i].real == real)
		{
			index = objectKeys[i].integer;
			break;
		}
	}
	return objectValues[index];
}
Token& Token::operator[](cstring str)
{
	int index;
	for (int i = 0; i < objectSize; i++)
	{
		if (objectKeys[i].str == str)
		{
			index = objectKeys[i].integer;
			break;
		}
	}
	return objectValues[index];
}


Parser::Parser()
{
}


Parser::~Parser()
{
}
int Parser::GetObjectSize(istream& in)
{
	//implementation : count ':'s between '{' and '}'
	streampos beginPos = in.tellg();
	int size = 0;
	while (true)
	{
		char c = in.get();
		if (c == ':')
			++size;
		else if (c == '}')
			break;
	}
	//�������������� �ǵ������´�.
	in.seekg(beginPos);
	return size;
}
int Parser::GetArraySize(istream& in)
{
	int size = 1;
	//implementation : count ','s between '[' and ']'
	streampos beginPos = in.tellg();
	while (true)
	{
		char c = in.get();
		if (c == ',')
			++size;
		else if (c == ']')
			break;
	}
	//�������������� �ǵ������´�.
	in.seekg(beginPos);
	return size;

}
JSON Parser::Parse(istream& in)
{
	JSON json;
	while (in.peek() != EOF)
	{
		IgnoreSpace(in);
		char c = GetChar(in);
		//if it's Object
		if (c == '{')
		{
			json.type = OBJECT;
			json.objectSize = GetObjectSize(in);
			json.objectKeys = new Token[json.objectSize];
			json.objectValues = new Token[json.objectSize];
			for (int i = 0; i < json.objectSize; i++)
			{
				IgnoreSpace(in);
				//key
				json.objectKeys[i] = Parse(in);
				//Colon (:)
				if (in.get() != ':')
					throw std::exception("Object Parse Error");
				//Value
				json.objectValues[i] = Parse(in); 
			}
			//( } )
			if (in.get() != '}')
				throw std::exception("Object Parse Error");
		}
		//if it's Array
		else if (c == '[')
		{
			json.type = OBJECT;
			json.objectSize = GetArraySize(in);
			json.objectKeys = new Token[json.objectSize];
			json.objectValues = new Token[json.objectSize];
			for (int i = 0; i < json.objectSize; i++)
			{
				IgnoreSpace(in);
				//Key
				//Here
				json.objectKeys[i] = Token();
			}

		}
	}

	return json;
}